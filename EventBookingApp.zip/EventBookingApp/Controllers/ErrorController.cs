using Microsoft.AspNetCore.Mvc;

namespace EventBookingApp.Controllers
{
    public class ErrorController : Controller
    {
        [HttpGet]
        public new IActionResult NotFound()
        {
            Response.StatusCode = 404;
            return View();
        }

        [HttpGet]
        public new IActionResult Unauthorized()
        {
            Response.StatusCode = 403;
            return View();
        }
    }
}