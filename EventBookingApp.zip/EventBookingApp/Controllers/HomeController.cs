﻿using System.Diagnostics;
using EventBookingApp.Data;
using Microsoft.AspNetCore.Mvc;
using EventBookingApp.Models;
using EventBookingApp.ViewModels;

namespace EventBookingApp.Controllers;

public class HomeController : Controller
{
    private readonly ApplicationDbContext _context;

    public HomeController(ApplicationDbContext context)
    {
        _context = context;
    }

    public IActionResult Privacy()
    {
        return View();
    }
    public IActionResult Index(string searchTerm)
    {
        var query = _context.Events.AsQueryable();

        if (!string.IsNullOrWhiteSpace(searchTerm))
        {
            query = query.Where(e => e.Title.Contains(searchTerm) || e.Description.Contains(searchTerm));
        }

        var model = new EventFilterViewModel
        {
            SearchTerm = searchTerm,
            Events = query.ToList()
        };

        return View(model);
    }

    public IActionResult Details(int id)
    {
        var eventItem = _context.Events.FirstOrDefault(e => e.Id == id);

        if (eventItem == null)
        {
            return NotFound();
        }

        return View(eventItem);
    }

    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error()
    {
        return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
    }
}
