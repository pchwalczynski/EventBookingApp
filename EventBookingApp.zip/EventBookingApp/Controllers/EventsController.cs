using System.Globalization;
using System.Text;
using Microsoft.AspNetCore.Mvc;
using EventBookingApp.Data;
using EventBookingApp.Models;
using Microsoft.AspNetCore.Authorization;

namespace EventBookingApp.Controllers
{
    [Authorize]
    public class EventsController : Controller
    {
        private readonly ApplicationDbContext _context;

        public EventsController(ApplicationDbContext context)
        {
            _context = context;
        }

        public IActionResult Index()
        {
            var userId = User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value;
            if (userId == null)
            {
                return Unauthorized();
            }

            var events = _context.Events.Where(e => e.UserId == userId).ToList();
            return View(events);
        }


        public IActionResult Create()
        {
            var userId = User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value;

            if (userId == null)
            {
                return Unauthorized();
            }

            ViewBag.UserId = userId;
            return View();
        }

        [HttpPost]
        public IActionResult Create(string title, string description, DateTime date, int availableSeats)
        {
            var userId = User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value;

            if (userId == null)
            {
                return Unauthorized();
            }

            var newEvent = new Event
            {
                Title = title,
                Description = description,
                Date = date,
                AvailableSeats = availableSeats,
                UserId = userId
            };

            if (string.IsNullOrWhiteSpace(newEvent.Title) || 
                string.IsNullOrWhiteSpace(newEvent.Description) || 
                newEvent.AvailableSeats <= 0)
            {
                return View(newEvent);
            }

            _context.Events.Add(newEvent);
            _context.SaveChanges();
    
            return RedirectToAction("Index");
        }

        public IActionResult Edit(int id)
        {
            var userId = User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value;
            
            if (userId == null)
            {
                return Unauthorized();
            }
            
            var eventToEdit = _context.Events.FirstOrDefault(e => e.Id == id && e.UserId == userId);
            
            if (eventToEdit == null)
            {
                return NotFound();
            }
            
            return View(eventToEdit);
        }

        [HttpPost]
        public IActionResult Edit(int id, Event editedEvent)
        {
            var userId = User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value;

            var existingEvent = _context.Events.FirstOrDefault(e => e.Id == id);

            if (existingEvent == null)
            {
                return NotFound();
            }

            if (existingEvent.UserId != userId)
            {
                return Unauthorized();
            }

            existingEvent.Title = editedEvent.Title;
            existingEvent.Description = editedEvent.Description;
            existingEvent.Date = editedEvent.Date;
            existingEvent.AvailableSeats = editedEvent.AvailableSeats;

            _context.Events.Update(existingEvent);
            _context.SaveChanges();

            return RedirectToAction("Index");
        }

        public IActionResult Delete(int id)
        {
            var userId = User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value;
            var eventToDelete = _context.Events.FirstOrDefault(e => e.Id == id && e.UserId == userId);
            if (eventToDelete == null)
            {
                return NotFound();
            }
            return View(eventToDelete);
        }

        [HttpPost, ActionName("Delete")]
        public IActionResult DeleteConfirmed(int id)
        {
            var userId = User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value;
            var eventToDelete = _context.Events.FirstOrDefault(e => e.Id == id && e.UserId == userId);
            if (eventToDelete != null)
            {
                _context.Events.Remove(eventToDelete);
                _context.SaveChanges();
            }
            return RedirectToAction("Index");
        }
        
        public IActionResult ExportToCsv()
        {
            var events = _context.Events.ToList();

            var csvBuilder = new StringBuilder();
            csvBuilder.AppendLine("Id,Name,Date,AvailableSeats");

            foreach (var ev in events)
            {
                csvBuilder.AppendLine($"{ev.Id},{ev.Title},{ev.Date.ToString("yyyy-MM-dd HH:mm", CultureInfo.InvariantCulture)},{ev.AvailableSeats}");
            }

            var fileName = $"events_{DateTime.Now:yyyyMMddHHmmss}.csv";
            return File(Encoding.UTF8.GetBytes(csvBuilder.ToString()), "text/csv", fileName);
        }
    }
}
