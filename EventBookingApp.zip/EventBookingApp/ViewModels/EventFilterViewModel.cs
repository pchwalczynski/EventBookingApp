using EventBookingApp.Models;

namespace EventBookingApp.ViewModels;

public class EventFilterViewModel
{
    public string SearchTerm { get; set; }
    public DateTime? StartDate { get; set; }
    public DateTime? EndDate { get; set; }
    public List<Event> Events { get; set; }
}