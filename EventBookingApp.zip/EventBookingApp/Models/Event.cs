using System;
using System.ComponentModel.DataAnnotations;

namespace EventBookingApp.Models
{
    public class Event
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "Tytuł jest wymagany.")]
        public string Title { get; set; }

        [Required(ErrorMessage = "Data jest wymagana.")]
        [DataType(DataType.Date)]
        public DateTime Date { get; set; }

        [Required(ErrorMessage = "Opis jest wymagany.")]
        public string Description { get; set; }

        [Required(ErrorMessage = "Liczba miejsc jest wymagana.")]
        [Range(1, 1000, ErrorMessage = "Liczba miejsc musi być między 1 a 1000.")]
        public int AvailableSeats { get; set; }

        public string UserId { get; set; }
    }
}
